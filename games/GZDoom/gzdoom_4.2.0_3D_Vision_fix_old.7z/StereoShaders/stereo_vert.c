//////////////////////////////////////////////////////////////////////////////////////////////////////////
// This work is licensed under a Creative Commons Attribution 3.0 Unported License.						//
// You are free to share, modify and adapt it for your needs, and even use it for commercial use.		//
// I would also love to hear about a project you are using it with.										//
// https://creativecommons.org/licenses/by/3.0/us/														//
//																										//
// Cheers!																								//
// Stephen Shepard aka sgsrules 																		//
//																										//
// Contact: sgsrules3dfixes@gmail.com																	//
//////////////////////////////////////////////////////////////////////////////////////////////////////////

#version 450
in vec2 vertex;
out vec2 texCoord;
out vec4 clipcoord;
out vec4 minmax;

uniform sampler2D dataTex;

void main()
{
	gl_Position    = vec4(vertex,0,1.0);
	texCoord = vertex*0.5+0.5;

	clipcoord = texture2D(dataTex, vec2(.25,.5));
	minmax = texture2D(dataTex, vec2(.75,.5));
}
