--PScript.lua for HelixMod

-- script.lua
-- Receives a table, returns the sum of its components.
-- io.write("The table the script received has:\n");
x = ""
pos = nil
pos1 = nil
defpos = nil
lastdefpos = nil
dclpos = nil
lastdclpos = nil
c7pos = nil
lastc7pos = nil
rpos = nil
xpos = nil
sr = ""
sx = ""
sw = ""
isDone = false
isDone1 = false
isDone2 = false
isDone3 = false
isDonea = false
doSearch = true
AddNextStr = true
IsFirst = true
IsFirst2 = true
Texture2D_2 = nil
view = nil
viewInverseMatrix = nil
cpos = nil
cpos2 = nil
cpos3 = nil
cpos4 = nil
cpos5 = nil
cposEnd = nil
cposEnd2 = nil
reg = nil
reg2 = nil
reg3 = nil
reg4 = nil
reg5 = nil
c7pos = nil
c7pos2 = nil
defline = 0
gCameraPos = nil
-- search for constants names it helps to determinate shader 
for i = 1, #SText do
	
	--if gCameraPos == nil then
	--	gCameraPos = string.find(SText[i], "gCameraPos")
	--end
	
	--x = x .. SText[i] .. string.char(13)
	if string.find(SText[i], "vs_3_0") ~= nil then
		defline = i + 1
		break
	end
end

if isDone == false then
	for i = 1, #SText do
		AddNextStr = true
		
		if (defline > 0) and (i == defline) then
			x = x .. "   def c254, 0, 1, 0.0625, 0.5" .. string.char(10) .. "dcl_2d s3" .. string.char(10) .. "dcl_texcoord8 o10.xyz" .. string.char(10)
		end
		
		if isDone == false then
		 
			if cpos == nil then
				cpos, cposEnd, reg = string.find(SText[i], "mov o3.xyz, (r%d).yzww")
			end
		
			if (reg ~= nil) then
				c7pos, cposEnd = string.find(SText[i], reg)
				if c7pos ~= nil then
					
					if IsFirst then
						AddNextStr=false
						x = x .. string.char(10) .. "    texldl r22, c254.z, s3" .. string.char(10)
						x = x .. "    mul r21.x, r22.y, c236.x" .. string.char(10)
						x = x .. "    mul r21.y, r22.y, c236.y" .. string.char(10)
						x = x .. "    mul r21.z, r22.y, c236.z" .. string.char(10)
						x = x .. "    mov r21.w, c254.x" .. string.char(10)
						x = x .. "    mul r20.x, c236.x, c236.x" .. string.char(10)
						x = x .. "    mad r20.x, c236.y, c236.y, r20.x" .. string.char(10)
						x = x .. "    mad r20.x, c236.z, c236.z, r20.x" .. string.char(10)
						x = x .. "    rcp r20.x, r20.x" .. string.char(10)
						x = x .. "    mul r21, r21, r20.x" .. string.char(10)
						x = x .. "    mad r23.y, -r22.x, r21.x, " .. reg .. ".y" .. string.char(10)
						x = x .. "    mad r23.z, -r22.x, r21.y, " .. reg .. ".z" .. string.char(10)
						x = x .. "    mad r23.w, -r22.x, r21.z, " .. reg .. ".w" .. string.char(10)
						x = x .. "    mov o10.xyz, r23.yzww" .. string.char(10).. SText[i] .. string.char(10)
					end
					IsFirst = false;
					str = string.sub(SText[i], 1, c7pos) 
					str = str .. string.sub(SText[i], cposEnd + 1) 
					SText[i] = str
						--doSearch = false
					isDone = true
						--AddNextStr = false
					
				end
			end
		end
		
		if (isDone1 == false) and (isDone == false) then
		 
			if cpos2 == nil then
				cpos2, cposEnd, reg2 = string.find(SText[i], "mov o3.xyz, (r%d)")
			end
		
			if (reg2 ~= nil) then
				c7pos, cposEnd = string.find(SText[i], reg2)
				if c7pos ~= nil then
					
					if IsFirst then
						AddNextStr=false
						x = x .. string.char(10) .. "    texldl r22, c254.z, s3" .. string.char(10)
						x = x .. "    mul r21.x, r22.y, c236.x" .. string.char(10)
						x = x .. "    mul r21.y, r22.y, c236.y" .. string.char(10)
						x = x .. "    mul r21.z, r22.y, c236.z" .. string.char(10)
						x = x .. "    mov r21.w, c254.x" .. string.char(10)
						x = x .. "    mul r20.x, c236.x, c236.x" .. string.char(10)
						x = x .. "    mad r20.x, c236.y, c236.y, r20.x" .. string.char(10)
						x = x .. "    mad r20.x, c236.z, c236.z, r20.x" .. string.char(10)
						x = x .. "    rcp r20.x, r20.x" .. string.char(10)
						x = x .. "    mul r21, r21, r20.x" .. string.char(10)
						x = x .. "    mad r23.x, -r22.x, r21.x, " .. reg2 .. ".x" .. string.char(10)
						x = x .. "    mad r23.y, -r22.x, r21.y, " .. reg2 .. ".y" .. string.char(10)
						x = x .. "    mad r23.z, -r22.x, r21.z, " .. reg2 .. ".z" .. string.char(10)
						x = x .. "    mov o10.xyz, r23" .. string.char(10).. SText[i] .. string.char(10)
					end
					IsFirst = false;
					str = string.sub(SText[i], 1, c7pos) 
					str = str .. string.sub(SText[i], cposEnd + 1) 
					SText[i] = str
						--doSearch = false
					isDone1 = true
						--AddNextStr = false
					
				end
			end
		end
		
		if (isDone2 == false) and (isDone == false) then
		 
			if cpos3 == nil then
				cpos3, cposEnd, reg3 = string.find(SText[i], "dp4 o%d.x, c8, (r%d)")
			end
		
			if (reg3 ~= nil) then
				c7pos, cposEnd = string.find(SText[i], reg3)
				if c7pos ~= nil then
					
					if IsFirst then
						AddNextStr=false
						x = x .. string.char(10) .. "    texldl r22, c254.z, s3" .. string.char(10)
						x = x .. "    mul r21.x, r22.y, c236.x" .. string.char(10)
						x = x .. "    mul r21.y, r22.y, c236.y" .. string.char(10)
						x = x .. "    mul r21.z, r22.y, c236.z" .. string.char(10)
						x = x .. "    mov r21.w, c254.x" .. string.char(10)
						x = x .. "    mul r20.x, c236.x, c236.x" .. string.char(10)
						x = x .. "    mad r20.x, c236.y, c236.y, r20.x" .. string.char(10)
						x = x .. "    mad r20.x, c236.z, c236.z, r20.x" .. string.char(10)
						x = x .. "    rcp r20.x, r20.x" .. string.char(10)
						x = x .. "    mul r21, r21, r20.x" .. string.char(10)
						x = x .. "    dp4 r23.x, c8, " .. reg3 .. string.char(10)
						x = x .. "    dp4 r23.y, c9, " .. reg3 .. string.char(10)
						x = x .. "    dp4 r23.z, c10, " .. reg3 .. string.char(10)
						x = x .. "    mad o10.x, -r22.x, r21.x, r23.x" .. string.char(10)
						x = x .. "    mad o10.y, -r22.x, r21.y, r23.y" .. string.char(10)
						x = x .. "    mad o10.z, -r22.x, r21.z, r23.z" .. string.char(10).. SText[i] .. string.char(10)
					end
					IsFirst = false;
					str = string.sub(SText[i], 1, c7pos) 
					str = str .. string.sub(SText[i], cposEnd + 1) 
					SText[i] = str
						--doSearch = false
					isDone2 = true
						--AddNextStr = false
					
				end
			end
		end
		
		--if (isDone2 == true) and (isDone3 == false) then
		--	if cpos4 == nil then
		--		cpos4, cposEnd, reg4 = string.find(SText[i], "mov o3.y, (r%d).x")
		--	end
		--	
		--	if (reg4 ~= nil) then
		--		c7pos, cposEnd = string.find(SText[i], reg4)
		--		if c7pos ~= nil then
		--			
		--			if IsFirst then
		--				AddNextStr=false
		--				x = x .. SText[i] .. string.char(10) .. "    mov o10.y, " .. reg4 .. ".x" .. string.char(10)
		--			end
		--			IsFirst = false;
		--			str = string.sub(SText[i], 1, c7pos) 
		--			str = str .. string.sub(SText[i], cposEnd + 1) 
		--			SText[i] = str
		--				--doSearch = false
		--			isDone3 = true
		--				--AddNextStr = false
		--			
		--		end
		--	end
		--end
		
		if isDonea == false then
		 
			if cpos5 == nil then
				cpos5, cposEnd, reg5 = string.find(SText[i], "mov o0, (r%d)")
			end
			
			if cpos5 == nil then
				cpos5, cposEnd, reg5 = string.find(SText[i], "mov o0.xyw, (r%d).xyw")
			end
		
			if (reg5 ~= nil) then
				c7pos, cposEnd = string.find(SText[i], reg5)
				if c7pos ~= nil then
					
					if IsFirst2 then
						AddNextStr=false
						x = x .. SText[i] .. string.char(10) .. "    texldl r22, c254.z, s3" .. string.char(10)
						x = x .. "    add r22.w, " .. reg5 .. ".w, -r22.y" .. string.char(10)
						x = x .. "    mad " .. reg5 .. ".x, r22.x, r22.w, " .. reg5 .. ".x" .. string.char(10)
					end
					IsFirst2 = false;
					str = string.sub(SText[i], 1, c7pos) 
					str = str .. string.sub(SText[i], cposEnd + 1) 
					SText[i] = str
						--doSearch = false
					isDonea = true
						--AddNextStr = false
					
				end
			end
		end
		if AddNextStr then
			x = x .. SText[i] .. string.char(10)
		end
	end
end

if (isDone == true) or (isDone1 == true) or (isDone2 == true) or (isDonea == true) then
	return x
else
	return ""
end;