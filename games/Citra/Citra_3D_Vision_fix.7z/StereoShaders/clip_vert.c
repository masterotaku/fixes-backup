//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// This work is licensed under a Creative Commons Attribution 3.0 Unported License.												//
// You are free to share, modify and adapt it for your needs, and even use it for commercial use.								//
// I would also love to hear about a project you are using it with.																//
// https://creativecommons.org/licenses/by/3.0/us/																				//
//																																//
// This shader recalulates the dynamic clipping planes, linearizes depth and automaically adjusts convergence to maximize depth	//
//																																//
// Cheers!																														//
// Stephen Shepard aka sgsrules 																								//
//																																//
// Contact: sgsrules3dfixes@gmail.com																							//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#version 450
#define customConvergence
in vec2 vertex;
out vec2 texCoord;
out vec4 clipcoord;
out vec4 minmax;
uniform sampler2D dataTex;
uniform sampler2D depthTex;

#define startNear .02
#ifdef customConvergence
uniform float convergence;
#else
float convergence = .55;
#endif

float zpd = 12;
float far = 1;
float maxConvergence =.5;
float maxNearClip = .1;
float linAvgThreshold =.2;
float avgThreshold = .03;
//-----------------------------------------------------------------------------

float LinearizeDepth(float depth, float cN, float cF)
{
	return 2.0 * cN * cF / (cF + cN - (2.0 * depth - 1.0) * (cF - cN));
}
//-----------------------------------------------------------------------------

float GetNearFromDepth(float targetLinearDepth, float depth)
{
 float cN = ((depth-1)*targetLinearDepth)/(depth*targetLinearDepth-1);
 return cN;
}
//-----------------------------------------------------------------------------

void main()
{
	gl_Position    = vec4(vertex,0,1.0);
	texCoord = vertex*.5+.5;
	return;
}
//-----------------------------------------------------------------------------
