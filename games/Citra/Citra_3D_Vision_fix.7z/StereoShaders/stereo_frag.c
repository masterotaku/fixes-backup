//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 		Original 3d depth shader code based off CryTech's 																			//
//		http://www.slideshare.net/TiagoAlexSousa/secrets-of-cryengine-3-graphics-technology											//
//		Special thanks to Jose Negrete AKA BlueSkyDefender for his SuperDepth3D implementation which started me down this path.		//
// 		Contact: sgsrules3dfixes@gmail.com																							//
//																																	//
//																																	//
//																																	//
// UPDATED by Helifax for 3D Vision usage																							//
// The original formula was incomplete. Based on the above link, the dynamic convergence was never used.							//					
// Contact: tavyhome@gmail.com																										//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#version 450

#define farClip 1.0
#define nearClip 0.01
// Tweak the depth map to make the close objects, like hands have depth
#define handDepthFactor 1.0
// Tweak the convergence formula for the blurring - hidding missing geome
#define blurFactor 0.15

in vec2 texCoord;
in vec4 clipcoord;
in vec4 minmax;
out vec4 fragColor;

uniform float isLeft;
uniform float g_eye_separation;
uniform float g_convergence;
uniform float pixelSize;
uniform float isVertFlipped;
uniform float linearisationMethod;
uniform sampler2D colorTex;
uniform sampler2D depthTex;

/*
/////////////////////////////////////////////////////////////
PROTOTYPES
/////////////////////////////////////////////////////////////
*/
//float GetDepth(vec2 texcoord, float viewMode);
//float RawDepth(vec2 texcoord,float viewMode);
//float RawDepthInverse(vec2 texcoord,float viewMode);
//float LinearizeDepth(vec2 texcoord,float viewMode);
//float LinearizeDepthInverse(vec2 texcoord,float viewMode);
//float LogarithmicDepth(vec2 texcoord,float viewMode);
//float LogarithmicDepthInverse(vec2 texcoord,float viewMode);

/*
/////////////////////////////////////////////////////////////
STEREO PASS
/////////////////////////////////////////////////////////////
*/
vec4 StereoPass()
{
	vec2 stereoTexCoord = texCoord;
	float minDepthL = 1.0, minDepthR = 1.0;
	
	//SBS to 3D Vision.
	stereoTexCoord.x=stereoTexCoord.x*0.5;
	if(isLeft>.5) {
		if (g_convergence<0.5) {
			stereoTexCoord.x+=0.01-0.005/g_convergence;
		}
	}
	else {
		if (g_convergence>=0.5) {
			stereoTexCoord.x+=0.55-g_convergence*0.1;
		}
		else {
			stereoTexCoord.x+=0.5;
		}
	}
	vec4 color = texture2D(colorTex, stereoTexCoord);
	return color;
}
//-----------------------------------------------------------------------------

/*
/////////////////////////////////////////////////////////////
MAIN FUNCTION
/////////////////////////////////////////////////////////////
*/

void main()
{
	fragColor = StereoPass();
}
//-----------------------------------------------------------------------------
