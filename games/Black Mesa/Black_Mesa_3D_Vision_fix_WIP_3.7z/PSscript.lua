--PScript.lua for HelixMod

-- script.lua
-- Receives a table, returns the sum of its components.
-- io.write("The table the script received has:\n");
 x = ""
 pos = nil
 pos1 = nil
 defpos = nil
 lastdefpos = nil
 dclpos = nil
 lastdclpos = nil
 c7pos = nil
 lastc7pos = nil
 rpos = nil
 xpos = nil
 sr = ""
 sx = ""
 sw = ""
 isDone = false
 doSearch = true
 AddNextStr = true
 IsFirst = true
 ScreenToLS = nil
 SceneColorTexture = nil
 SamplerPos = nil
 SamplerName = ""
 MulEnd = nil
 rposEnd = nil;
 LightAttenuationTexture = nil
 textcordpos = nil
 textcordreg = ""
 FixSceneColorTexture = true
 FixShadowsHalo = true
 UniformPixelVector = nil
 MinZ_MaxZRatio = nil
 ShadowTexture = nil
 VPreg = ""
 VPPos = nil
 LstIdx = 0;
 LightMapTextures = nil
 UniformPixelScalars = nil
 ScreenPositionScaleBias = nil
 Texture2D_2 = nil
 g_EyePos = nil
 EnvmapSampler = nil
 cpos = nil
 cpos2 = nil
 cposEnd = nil
 cposEnd2 = nil
 reg = nil
 reg2 = nil
 c7pos = nil
 c7pos2 = nil
 -- search for constants names it helps to determinate shader 
 for i = 1, #SText do
	
	if g_EyePos == nil then
		g_EyePos = string.find(SText[i], "g_EyePos")
	end
	
	if EnvmapSampler == nil then
		EnvmapSampler = string.find(SText[i], "EnvmapSampler")
	end
	
	x = x .. SText[i] .. string.char(13)
	if string.find(SText[i], "ps_3_0") ~= nil then
		break
	end
 end

 if isDone == false then
 if ((g_EyePos ~= nil) and (EnvmapSampler ~= nil)) then 
 for i = 1, #SText do
    AddNextStr = true
	if doSearch then
 
		lastdefpos = string.find(SText[i], "def")
		if lastdefpos ~= nil then
			defpos = i + 1
		end
		
		
		if cpos == nil then
			cpos, cposEnd = string.find(SText[i], ".xyz, c10, %-v")
			if cpos ~= nil then
			    cpos = string.find(SText[i], "." ,cpos, true)
				reg = string.sub(SText[i], cpos - 1, cpos - 1) 
			end
			--defpos = i + 1
		end
		
		if cpos2 == nil then
			cpos2, cposEnd2 = string.find(SText[i], ".xyz, %-c20, v")
			if cpos2 ~= nil then
			    cpos2 = string.find(SText[i], "." ,cpos2, true)
				reg2 = string.sub(SText[i], cpos2 - 1, cpos2 - 1) 
			end
			--defpos = i + 1
		end
	
		if (lastdefpos == nil) and (defpos ~= nil) then
			if i == defpos then
				x = x .. "   def c200, 0.0, 0.5, 0.0625, 0" .. string.char(10)	.. "dcl_2d s13" .. string.char(10)
			end
			
			if reg ~= nil then
				c7pos, cposEnd = string.find(SText[i], reg)
				if c7pos ~= nil then
					
					if IsFirst then
						AddNextStr=false
						x = x .. SText[i] .. string.char(10) .. "    texldl r10, c200.z, s13" .. string.char(10)
						x = x .. "    mul r11.x, r10.y, c52.x" .. string.char(10)
						x = x .. "    mul r11.y, r10.y, c53.x" .. string.char(10)
						x = x .. "    mul r11.z, r10.y, c54.x" .. string.char(10)
						x = x .. "    mul r11.xyz, r11.xyz, c222.x" .. string.char(10)
						x = x .. "    mad r" .. reg ..".xyz, r10.xxx, r11.xyz, r" .. reg ..".xyz" .. string.char(10)
					end
					IsFirst = false;
					str = string.sub(SText[i], 1, c7pos) 
					str = str .. string.sub(SText[i], cposEnd + 1) 
					SText[i] = str
						--doSearch = false
					isDone = true
						--AddNextStr = false
					
				
				end
			end
			
			if reg2 ~= nil then
				c7pos2, cposEnd2 = string.find(SText[i], reg2)
				if c7pos2 ~= nil then
					
					if IsFirst then
						AddNextStr=false
						x = x .. SText[i] .. string.char(10) .. "    texldl r10, c200.z, s13" .. string.char(10)
						x = x .. "    mul r11.x, r10.y, c52.x" .. string.char(10)
						x = x .. "    mul r11.y, r10.y, c53.x" .. string.char(10)
						x = x .. "    mul r11.z, r10.y, c54.x" .. string.char(10)
						x = x .. "    mul r11.xyz, r11.xyz, c222.x" .. string.char(10)
						x = x .. "    mad r" .. reg2 ..".xyz, -r10.xxx, r11.xyz, r" .. reg2 ..".xyz" .. string.char(10)
					end
					IsFirst = false;
					str = string.sub(SText[i], 1, c7pos2) 
					str = str .. string.sub(SText[i], cposEnd2 + 1) 
					SText[i] = str
						--doSearch = false
					isDone = true
						--AddNextStr = false
					
				
				end
			end
		end
	end
	if AddNextStr then
		x = x .. SText[i] .. string.char(10)
	end
end
end
end

if isDone then
	return x
else
	return ""
end;