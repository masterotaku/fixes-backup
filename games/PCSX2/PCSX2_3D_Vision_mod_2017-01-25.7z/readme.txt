Used tools: 3Dmigoto 1.2.54 and SpecialK 0.7.0

Source of 3Dmigoto: https://github.com/bo3b/3Dmigoto
Source of SpecialK: https://github.com/Kaldaien/SpecialK


Q: What does this mod do?

A: This has two parts:

1- SpecialK ("d3d9.dll" and "d3d9.ini"): it allows PCSX2 to enable exclusive fullscreen mode,
by pressing Alt+Enter after you are in borderless windowed mode (fake fullscreen), but it will only work
if you enter GSdx settings before booting a game. The renderer must be set to DX11 hardware renderer. OpenGL will crash the emulator.

2- 3Dmigoto. It's usually used to fix shaders in games to make them correct in 3D Vision, when the 3D Vision Automatic drivers
don't do it correctly. This time, it's focused on one thing: converting "side by side" and "top and bottom" stereoscopic 3D
modes into something that works on 3D Vision (frame packed 3D).


Q: I have a 3D Vision monitor and glasses, how do I play PCSX2 in 3D?

A: After placing the contents of this mod in your PCSX2 root folder, you need to get a custom GSdx plugin that has
stereoscopic 3D options (at this moment they aren't in official builds). The latest version at this moment, 2017/01/25
is here: http://forums.pcsx2.net/Thread-Gsdx-3D-Stereoscopy-Patch?pid=522990#pid522990

Then, place those DLLs in the "plugins" folder, and select one of them in the PCSX2 plugins selection. After that, select
one of these two "Stereo Mode" options: "Half-SBS Left/Right" or "Half-OU Top/Bottom".

Now, remember what I said in the first answer. Before booting any game, you need to open and close the GSdx configuration. Now
boot a game, enable the exclusive fullscreen mode, and press F11 once if you selected "Half-SBS Left/Right" or twice if you selected
"Half-OU Top/Bottom". The game should be in 3D now. While you are playing a game, don't go back to the GSdx settings. You won't be able
to come back to the game until you reopen PCSX2 again.


Q: What settings do you recommend?

A: I definitely recommend the "Half-OU Top/Bottom" mode over the other one. With internal resolution multipliers in PCSX2, you end up with
a lot of vertical resolution to spare, while the horizontal resolution won't be much higher. That's because the native resolution of PS2 games
is usually 512x448, and sometimes 640x448. A lot more "thin" than 16:9, so you don't want to lose horizontal resolution with 3D.

I also recommend using Nvidia DSR at the desktop, using the highest resolution you can. Like 5120x2880 in 2560x1440 monitors,
or 3840x2160 in 1920x1080 monitors. The reason is that the shaders that convert PCSX2's 3D to 3D Vision do some stretching operations, and you lose
a lot of resolution if you are using your native resolution.

Each game needs some specific separation and "convergence" (not really pure convergence) values to play it at its best state. They can be changed
with "+", "-", "shift and +" and "shift and -". Plus and minus characters must be from the numpad, if I remember correctly. Check the "pcsx2_3D.txt"
file to see what values you need to put in the "GSdx.ini" file, which is inside the "inis" folder. They are configured for my taste and can be used
to have a good starting configuration.