--PScript.lua for HelixMod

-- script.lua
-- Receives a table, returns the sum of its components.
-- io.write("The table the script received has:\n");
x = ""
pos = nil
pos1 = nil
defpos = nil
lastdefpos = nil
dclpos = nil
lastdclpos = nil
c7pos = nil
lastc7pos = nil
rpos = nil
xpos = nil
sr = ""
sx = ""
sw = ""
isDone = false
isDonea = false
doSearch = true
AddNextStr = true
IsFirst = true
IsFirst2 = true
Texture2D_2 = nil
view = nil
viewInverseMatrix = nil
cpos = nil
cpos2 = nil
cpos3 = nil
cposEnd = nil
cposEnd2 = nil
reg = nil
reg2 = nil
reg3 = nil
reg4 = nil
c7pos = nil
c7pos2 = nil
defline = 0
-- search for constants names it helps to determinate shader 
for i = 1, #SText do
	
	if view == nil then
		view = string.find(SText[i], "//   g_View ")
	end
	
	if viewInverseMatrix == nil then
		viewInverseMatrix = string.find(SText[i], "//   g_ViewInverseMatrix")
	end
	
	x = x .. SText[i] .. string.char(13)
	if string.find(SText[i], "vs_3_0") ~= nil then
		defline = i + 1
		break
	end
end

if isDone == false then
	for i = 1, #SText do
		AddNextStr = true
		
		if (defline > 0) and (i == defline) then
			x = x .. "   def c200, 0, 1, 0.0625, 0.5" .. string.char(10)	.. "dcl_2d s0" .. string.char(10)
		end
		
		if (view ~= nil) and (viewInverseMatrix ~= nil) and (isDone == false) then 
		 
			if cpos == nil then
				cpos, cposEnd, reg = string.find(SText[i], "mov r(%d).z, %-c14.w")
				--defpos = i + 1
			end
			
			if (cpos2 == nil) and (reg ~= nil) then
				cpos2, cposEnd2, reg3, reg2 = string.find(SText[i], "add (%a%d).xyz, r" .. reg .. ", r(%d)")
				--defpos = i + 1
			end
			
			if (cpos2 == nil) and (reg ~= nil) then
				cpos2, cposEnd2, reg3, reg2 = string.find(SText[i], "add (%a%d).xyz, r(%d), r" .. reg)
				--defpos = i + 1
			end
			
			if (reg ~= nil) and (reg2 ~= nil) then
				c7pos, cposEnd = string.find(SText[i], reg2)
				if c7pos ~= nil then
					
					if IsFirst then
						AddNextStr=false
						x = x .. "    texldl r20, c200.z, s0" .. string.char(10)
						x = x .. "    mul r21.xyz, r20.yyy, c16.z" .. string.char(10)
						x = x .. "    mul r21.xyz, r21.xyz, c0.xyz" .. string.char(10)
						x = x .. "    mul r21.xyz, r21.xyz, c235.z" .. string.char(10)
						x = x .. "    mad r" .. reg2 ..".xyz, -r20.xxx, r21.xyz, r" .. reg2 ..".xyz" .. string.char(10) .. SText[i] .. string.char(10)
					end
					IsFirst = false;
					str = string.sub(SText[i], 1, c7pos) 
					str = str .. string.sub(SText[i], cposEnd + 1) 
					SText[i] = str
						--doSearch = false
					isDone = true
						--AddNextStr = false
					
				
				end
			end
		end
		if (view == nil) and (viewInverseMatrix ~= nil) and (isDone == false) then 
		 
			if cpos == nil then
				cpos, cposEnd, reg = string.find(SText[i], "mov r(%d).z, %-c14.w")
				--defpos = i + 1
			end
			
			if (cpos2 == nil) and (reg ~= nil) then
				cpos2, cposEnd2, reg3, reg2 = string.find(SText[i], "add (%a%d).xyz, r" .. reg .. ", r(%d)")
				--defpos = i + 1
			end
			
			if (cpos2 == nil) and (reg ~= nil) then
				cpos2, cposEnd2, reg3, reg2 = string.find(SText[i], "add (%a%d).xyz, r(%d), r" .. reg)
				--defpos = i + 1
			end
		
			if (reg ~= nil) and (reg2 ~= nil) then
				c7pos, cposEnd = string.find(SText[i], reg2)
				if c7pos ~= nil then
					
					if IsFirst then
						AddNextStr=false
						x = x .. "    texldl r20, c200.z, s0" .. string.char(10)
						x = x .. "    mul r21.xyz, r20.yyy, c16.z" .. string.char(10)
						x = x .. "    mul r21.xyz, r20.yyy, c16.z" .. string.char(10)
						x = x .. "    mul r21.xyz, r21.xyz, c21.xyz" .. string.char(10)
						x = x .. "    mul r21.xyz, r21.xyz, c235.z" .. string.char(10)
						x = x .. "    mad r" .. reg2 ..".xyz, -r20.xxx, r21.xyz, r" .. reg2 ..".xyz" .. string.char(10) .. SText[i] .. string.char(10)
					end
					IsFirst = false;
					str = string.sub(SText[i], 1, c7pos) 
					str = str .. string.sub(SText[i], cposEnd + 1) 
					SText[i] = str
						--doSearch = false
					isDone = true
						--AddNextStr = false
					
				
				end
			end
		end
		if isDonea == false then
		 
			if cpos3 == nil then
				cpos3, cposEnd, reg4 = string.find(SText[i], "mov o0, (r%d)")
			end
			
			if cpos3 == nil then
				cpos3, cposEnd, reg4 = string.find(SText[i], "mov o0.xyw, (r%d).xyw")
			end
		
			if (reg4 ~= nil) then
				c7pos, cposEnd = string.find(SText[i], reg4)
				if c7pos ~= nil then
					
					if IsFirst2 then
						AddNextStr=false
						x = x .. SText[i] .. string.char(10) .. "    texldl r22, c200.z, s0" .. string.char(10)
						x = x .. "    if_ne " .. reg4 .. ".w, c200.y" .. string.char(10)
						x = x .. "    add r22.w, " .. reg4 .. ".w, -r22.y" .. string.char(10)
						x = x .. "    mad " .. reg4 .. ".x, r22.x, r22.w, " .. reg4 .. ".x" .. string.char(10)
						x = x .. "    endif" .. string.char(10)
					end
					IsFirst2 = false;
					str = string.sub(SText[i], 1, c7pos) 
					str = str .. string.sub(SText[i], cposEnd + 1) 
					SText[i] = str
						--doSearch = false
					isDonea = true
						--AddNextStr = false
					
				end
			end
		end
		if AddNextStr then
			x = x .. SText[i] .. string.char(10)
		end
	end
end

if (isDone == true) or (isDonea == true) then
	return x
else
	return ""
end;