Widescreen fix for Prince of Persia: The Two Thrones ver 1.0.0.188
Created by nemesis2000 <nemesis2000@yandex.ru>
Downloaded from http://ps2wide.net/pc.html

Installation Instructions
=========================================================================

1. Unpack [password: pop3]
2. Edit pop3.ini
3. Enjoy


Additional Information
=========================================================================

1. Supported exe size: 6�344�704 bytes


References
=========================================================================

1. UPX: the Ultimate Packer for eXecutables <http://upx.sourceforge.net/>