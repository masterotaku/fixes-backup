

//////////////////////////////////////////////////////////////////////////////////////////////////////////
// This work is licensed under a Creative Commons Attribution 3.0 Unported License.						//
// You are free to share, modify and adapt it for your needs, and even use it for commercial use.		//
// I would also love to hear about a project you are using it with.										//
// https://creativecommons.org/licenses/by/3.0/us/														//
//																										//    
// Copies data from getClip shader so that it can be read during the next frame.                        //
//																										//
// Cheers!																								//
// Stephen Shepard aka sgsrules 																		//
// Contact: sgsrules3dfixes@gmail.com																	//
//																										//
// Octavian Vasilovici aka Helifax																		//
// Contact: tavyhome@gmail.com																			//
//////////////////////////////////////////////////////////////////////////////////////////////////////////

#version 450

in vec2 texCoord;

uniform sampler2D dataTex;

out vec4 fragColor;


void main()
{
 fragColor = texture2D(dataTex,texCoord);
}
