//////////////////////////////////////////////////////////////////////////////////////////////////////////
// This work is licensed under a Creative Commons Attribution 3.0 Unported License.						//
// You are free to share, modify and adapt it for your needs, and even use it for commercial use.		//
// I would also love to hear about a project you are using it with.										//
// https://creativecommons.org/licenses/by/3.0/us/														//
//																										//
// Cheers!																								//
//																										//
// Stephen Shepard aka sgsrules 																		//
// Contact: sgsrules3dfixes@gmail.com																	//
//																										//
// Octavian Vasilovici aka Helifax																		//
// Contact: tavyhome@gmail.com																			//
//////////////////////////////////////////////////////////////////////////////////////////////////////////

#version 450

in vec2 texCoord;

out vec4 fragColor;

uniform sampler2D depthTex;
uniform sampler2D colorTex;
uniform float pixelSize;

void main()
{
	float colorm = texture2D(depthTex, texCoord).x ;
	float colorl = 0;
	float colorr = 0;
	const int blurSamples = 1;
	for(int i = 0; i < blurSamples; ++i)
	{
		colorl += texture2D(depthTex, texCoord + vec2(i* (pixelSize), 0.0)).x ;
		colorr += texture2D(depthTex, texCoord - vec2(i* (pixelSize), 0.0)).x ;
	}
	colorr/=blurSamples;
	colorl/=blurSamples;
	fragColor = vec4(colorm,colorl,colorr,1.0);	
}
