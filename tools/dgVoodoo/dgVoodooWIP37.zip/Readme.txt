dgVoodoo WIP only version
-------------------------

=========================
WIP35:
=========================

This version is the same as 2.54, with some minor fixes:

- Issue of mixed type stream sources is fixed (D3D8, missing player characters in Final Fantasy XI)
- A bug in the shader code validator resulted in uncreated shaders, fixed (D3D8, Mace Griffin Bounty Hunter)
- dgVoodoo CPL cosmetic: missing logo bitmap when monitor scale is >150%, fixed

=========================
WIP36:
=========================

- Text based (INI) config file support with some new options (and more to come later) for experts (and modders?)
- Experimental (and now minimal) optional logging of Info/Warning/Error entries in the debug and
  spec release builds, in order to trace issues
- D3D8 cursor handling and viewport depth scaling bugs fixed (WildFire)
- D3D8 software vertex processing bug, fixed (Mafia - multipass rendering)
- Bugs causing crash and black screen are fixed (Empires Dawn of The Modern World)
- D3D parameter validation incompatibility, fixed (Praetorians)
- D3D state block incompatibility, fixed (Soldiers of Anarchy)
- D3D non-W-friendly matrix in ComputeSphereVisibility calcs, fixed (Pac-Man Adventures in Time)
- D3D FVF validation incompatibility, fixed (Earthworm Jim 3D)
- D3D8 GetFrontBufferData bug, fixed (Rome Total War) (movies only, ingame still has the old issues)
- Old D3D-lighting incompatibility, fixed (when revising code and docs)
- Introducing built-in deframing for forced resolutions
- Introducing the ability of integer scaling (pixel multiplying) of output images (coming from wrapped API's)
  into dgVoodoo's scaling process
- ATI and GeForce profiles are modified to force W-pixelfog (compatibilities with old drivers).
- A new scaling mode with idiot name (Centered, keep Aspect Ratio) is added. Same as 'Centered' but scaling is
  done by the wrapper

About config files: dgVoodoo.conf is still the one containing the configuration.
Now it can have two formats: binary and INI. Wrapper dlls and the CPL can read both.
CPL writes only binary, you can convert an INI to binary. Be careful, the CPL won't backup your
existing configuration file but simply overwrites that.
INI files contains some extra options that aren't available through the CPL. If an option isn't
specified in the INI file then the default value is used for the given property.
The attached config file contains the default configuration.
The last supported binary version of config files is 2.40, earlier ones can't be read (I hope no
one cares about that).

=========================
WIP37:
=========================

- Regression bug causing DDraw crashes (like in Settlers IV) fixed
- Cosmetics
- New dynamic resolution modes (2x, 3x, ...) are added
- Possibility of extra resolutions enumerable to DirectX applications is added
- Dithering for Glide and DirectX added

Glide dithering:

- You can either force-disable it, ending up 16-bit quality rendering
- Or set it to 'app driven' meaning the application can choose between disabling, dithering2x2 and dithering4x4
- Or you can force a dithering method: pure32bit (meaning pure 32 bit rendering quality), dither2x2 or dither4x4

DirectX dithering:

An application has two options for controlling dithering: enable or disable. Also, dithering typically affected
only 16 bit surfaces back in old DX days. So,

- You can either force-disable it, ending up 16-bit quality rendering on 16 bit surfaces.
- Or set it to 'app driven' along with defining a dithering method, so the app can enable/disable dithering
  for displaying 16 bit surfaces
- Or you can force the given dithering method for 16 bit surfaces (forceon16bit)
- Or you can force the given dithering method for all displayed surfaces (forcealways)
- Dithering methods are: pure32bit, ordered2x2, ordered4x4

dgVoodoo implements dithering as a rendering postprocess effect (plain "ordered dithering" methods for the time being),
unlike contemporary GPU's which applied it at perpixel level during 3D-rendering. Thus, the two can't be equivalent.
When dithering is application driven then dithered rendered data can be (partially) produced, copied, stretch-copied,
etc (DX). dgVoodoo cannot do such level of tracing, keep it in mind for 'appdriven' cases. Also, to have real
retro feel&look, you can scale the size of the dithering matrix for pixelated appearance, even by leaving calculating
the scale factor to dgVoodoo.